/* Miguel Ivan Orona
 * February 25, 2018
 * CSC-151
 * this program will calculate the payroll for the user.
 */
package payrolldialog_oronamiguel;

/**
 *
 * @author oronam7447
 */
public class PayrollDialog_OronaMiguel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        String inputString;  // For reading input
        String name;        // The user's name
        int hours;          // The number of hours worked
        double payRate;     // The user's hourly pay rate
        double grossPay;    // The user's gross pay
        
        //Get the user's name.
        name = JOptionPane.showInputDialog("what is " + 
                "your name? ");
        
        //Get the hours worked.
        inputString = 
                JOptionPane.ShowInputDialog ("How many hours " +
                        "did you work this week? ");
        
        //Convert the input to an int.
        hours = Integer.parseInt(inputString);
        
        //Get the hourly pay rate.
        inputString = 
                JOptionPane.ShowInputDialog("What is your " +
                        "hourly pay rate? ");
        
        //Convert the input to a double.
        payRate = Double.parseDouble(inputString);
        
        //Calculate gross pay.
        grossPay = hours * payRate;
        
        //Display the results.
        JOptionPane.showMessageDialog(null, "Hello " +
                name + ". Your gross pay is $" +
                grossPay);
        
        //End program.
        System.exit(0);
    }
    
}
