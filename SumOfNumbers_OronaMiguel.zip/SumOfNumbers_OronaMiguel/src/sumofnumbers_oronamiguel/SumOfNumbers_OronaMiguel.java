
package sumofnumbers_oronamiguel;
import java.util.Scanner;
public class SumOfNumbers_OronaMiguel {
    public static void main(String[] args)
    {
        int finalNumber_MIO;
        int startNumber_MIO = 0;
        int total_MIO = 0;
        
        Scanner keyboard = new Scanner (System.in);
        
        System.out.println("Please enter a positive number that isn't zero.");
        finalNumber_MIO = keyboard.nextInt();
        
        while (finalNumber_MIO < 1)
        {
            System.out.println("That number is not valid.");
            System.out.println("Please enter a positive number that isn't zero");
            finalNumber_MIO = keyboard.nextInt();
        }
        
        
        while (startNumber_MIO <= finalNumber_MIO)
       {
           total_MIO += startNumber_MIO;
           startNumber_MIO++;
       }
        
        System.out.println("The sum of all integers "
                + "from 1 through " + finalNumber_MIO +""
                        + " and the sum of the running numbers "
                        + "is " + total_MIO);
    }
}
