/**
* This program will 
* April 9, 2018
* CSC 151 Tutorial 4 - Pennies for Pay Problem
* @author Miguel Ivan Orona
*/
package penniesforpay_oronamiguel.java;

import java.util.Scanner;
import java.text.DecimalFormat;

public class PenniesForPay_OronaMiguelJava {

    public static void main(String[] args) 
    {
        int pennies_MIO;    //Penny accumulator
        int totalPay_MIO;   //Total Pay accumulator
        int maxDays_MIO;    //Max number of days
        int dayCount_MIO;   //Day counter
        
        //Create a Scanner object for keyboard input.
        Scanner keyboard = new Scanner(System.in);
        
        //Get the maximum number of days.
        System.out.print("For how many days will you work? ");
        maxDays_MIO = keyboard.nextInt();
        
        //Validate the input.
        while (maxDays_MIO < 1)
        {
            //Prompt the user to enter correct value.
           System.out.println("The number of days must be at least 1.");
           System.out.println("Enter the number of days: ");
           maxDays_MIO = keyboard.nextInt();
        }   
           //Initialize the day counter to day 1.
           dayCount_MIO = 1;
           
           //Initialize the penny accumulator for
           //the first day of work
           pennies_MIO = 1;
           
           //Initialize the total pay accumalator
           totalPay_MIO = 0;
           
           //Display the report header.
           System.out.println();
           System.out.println("Day\t\tPennies Earned");
           System.out.println("--------------------------------");
           
           //Display the income report.
           while (dayCount_MIO <= maxDays_MIO)
           {
               //Display the day number and pennies earned.
               System.out.println(dayCount_MIO + "\t\t" + pennies_MIO);
               
               //Accumulate the total pay.
               totalPay_MIO += pennies_MIO;
               
               //Increment dayCount for the next day.
               dayCount_MIO++;
               
               //Double the number of pennies.
               pennies_MIO *= 2;
           }
           
           //Create the DecimalFormat object to format output.
           DecimalFormat dollar = new DecimalFormat("#,##0.00");
           
           //Display the total pay.
           System.out.println("Total pay, $" + dollar.format(totalPay_MIO / 100.0));
        }
}
