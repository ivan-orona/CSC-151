/*
 * This program will calculate the average of 
 * three given test scores and display the result.
 * March 19, 2018
 * CSC 151 Homework #2 - Test Average
 * Miguel Ivan Orona
 */
package testaverage_oronamiguel;
import java.util.Scanner;
/**
 *
 * @author oronam7447
 */
public class TestAverage_OronaMiguel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        double score1_MIO;
        double score2_MIO;
        double score3_MIO;
        double avg_MIO;
        double total_MIO;
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("Enter the first score: ");
        score1_MIO = keyboard.nextDouble();
        
        System.out.println("Enter another score: ");
        score2_MIO = keyboard.nextDouble();
        
        System.out.println("Enter the third and final score: ");
        score3_MIO = keyboard.nextDouble();
        
        total_MIO = score1_MIO + score2_MIO + score3_MIO;
        avg_MIO = total_MIO / 3;
        
        System.out.println("The total score is " + total_MIO);
        System.out.println("The average score is " + avg_MIO);     
    }
    
}
//End of program.