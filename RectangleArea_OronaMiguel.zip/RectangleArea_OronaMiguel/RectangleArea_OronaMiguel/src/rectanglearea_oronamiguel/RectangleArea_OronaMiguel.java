/**
* This program will receive the input from the user for 
* the length/width of a rectangle and output the area.
* April 30, 2018
* CSC 151 Homework 5 - Rectangle Area - Complete the Program
* Miguel Ivan Orona
*/
package rectanglearea_oronamiguel;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class RectangleArea_OronaMiguel 
{
    public static void main(String[] args) 
    {
        double length_MIO;    // The rectangle's length
        double width_MIO;     // The rectangle's width
        double area_MIO;      // The rectangle's area
        
        //Create a scanner object.
        Scanner keyboard = new Scanner(System.in);
        
      // Get the rectangle's length from the user.
      JOptionPane.showMessageDialog(null, "Enter the length of the rectangle: ");
      length_MIO = keyboard.nextDouble();
   
      // Get the rectangle's width from the user.
      JOptionPane.showMessageDialog(null, "Enter the width of the rectangle: ");
      width_MIO = keyboard.nextDouble();

      // Get the rectangle's area.
      area_MIO = (length_MIO * width_MIO);

      // Display the rectangle data.
      JOptionPane.showMessageDialog(null, "The area of your "
              + "rectangle is: " + area_MIO);
    }
}
