﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace softwareSales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
             
            int number;
            double discount;
            double totalDiscount;
            double baseTotal;
            double grandTotal;
            number = int.Parse(purchaseBox.Text);

            if (number >= 100) ;
            {
                discount = .50;
                baseTotal = (number * 99);
                totalDiscount = (baseTotal * .50);
                grandTotal = (baseTotal - totalDiscount);
                discountBox.Text = (" Discount is " + totalDiscount);
                totalBox.Text = ("Grand total is " + grandTotal);
            }
   
            else if (number >= 50 && number <= 99) ;
            {
                discount = .40;
                totalDiscount = (number * .40);
                baseTotal = (number * 99);
                grandTotal = (baseTotal - totalDiscount);
                discountBox.Text = ("Total discount is " + totalDiscount);
                totalBox.Text = ("Grand total is " + grandTotal);
            }
            else if (number >= 20 && number <= 49) ;
            discount = .30;
            totalDiscount = (number * .30);
            baseTotal = (number * 99);
            grandTotal = (baseTotal - totalDiscount);
            discountBox.Text = ("Total discount is " + totalDiscount);
            totalBox.Text = ("Grand total is " + grandTotal);

            else if (number >= 10 && number <= 19) ;
            discount = .20;
            totalDiscount = (number * .20);
            baseTotal = (number * 99);
            grandTotal = (baseTotal - totalDiscount);
            discountBox.Text = ("Total discount is " + totalDiscount);
            totalBox.Text = ("Grand total is " + grandTotal); 

            else 
            discountBox.Text = ("No discount applied.");

        }
    
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
