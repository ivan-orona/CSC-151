
package internetserviceprovider_oronamiguel;
import java.util.Scanner;
/**
 *
 * @author oronam7447
 */
public class InternetServiceProvider_OronaMiguel 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        double hoursUsed_MIO;
        double packagePurchased_MIO;
        double packageA_MIO; 
        double packageB_MIO;
        double packageC_MIO;
        double hoursUsedA_MIO;
        double hoursUsedB_MIO;
        double hoursUsedC_MIO;
        
        
        packageA_MIO = 9.95;
        packageB_MIO = 13.95;
        packageC_MIO = 19.95;
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("Enter the normal price"
                + " of your package: ");
        packagePurchased_MIO = keyboard.nextDouble();

        
        if (packagePurchased_MIO == packageA_MIO); 
        {
         System.out.println("How many hours were used? ");
         hoursUsed_MIO = keyboard.nextDouble();
            if (hoursUsed_MIO > 10)
            {
            hoursUsedA_MIO = ((hoursUsed_MIO - 10)*2);
            System.out.println("You went over your allotted"
                    + " usage and are billed an "
                    + " extra " +hoursUsed_MIO);
            }
            else
            {
            System.out.println("You are being charged your normal"
                    + " bill of $9.95");
            }
        }
        if (packagePurchased_MIO == packageB_MIO);
        {
        System.out.println("How many hours were used? ");
        hoursUsed_MIO = keyboard.nextDouble();
            if (hoursUsed_MIO > 20)
            {
            hoursUsedB_MIO = (hoursUsed_MIO - 20);
            System.out.println("You went over our allotted"
                    + " usage and are billed an"
                    + " extra " +hoursUsedB_MIO);
            }
            else
            {
                System.out.println("You are being charged your normal"
                    + " bill of $13.95");
            }
        }
        if (packagePurchased_MIO == packageC_MIO)
        {
        System.out.println("You have unlimited acces and "
                + " will be billed your normal "
                + " amount of $19.95");
        }
        else
        {
        System.out.println("That is not a valid package plan!");
        }
    }
}
