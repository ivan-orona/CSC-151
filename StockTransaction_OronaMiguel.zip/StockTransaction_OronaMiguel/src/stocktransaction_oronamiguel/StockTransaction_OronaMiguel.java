/*
 */
package stocktransaction_oronamiguel;

/**
 *
 * @author oronam7447
 */
public class StockTransaction_OronaMiguel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        
        double paidShare;   //MO
        double soldShare;   //MO
        double brokerPay;   //MO
        double totalPricePaid;  //MO
        double totalPriceSold;  //MO
                
        paidShare = 32.87;
        soldShare = 33.92;   
        brokerPay = .02;
        totalPricePaid = 
        totalPriceSold = 
                
                
        System.out.println("Joe paid" + paidShare + "for "
                + "each stock he bought.");
        System.out.println("His Stockbroker earned a " + brokerPay + 
                "commission"
                + " and recieved $" + totalPricePaid * brokerPay +
        ".");
        System.out.println("Taking into account the cut for "
                + "his stock broker, Joe paid "
                + "a total of " + totalPricePaid - )
        System.out.println("Joe then sold each share of stock "
                + " for " + soldShare + " a grand"
                        + " total of $" totalPriceSold".");
        System.out.println("Joe's Stockbroker recieved"
                + " a 2% commission totaling to"
                + " $678.40.");
        System.out.println("Joe's total at the end of the day: ");
    }
    
}
