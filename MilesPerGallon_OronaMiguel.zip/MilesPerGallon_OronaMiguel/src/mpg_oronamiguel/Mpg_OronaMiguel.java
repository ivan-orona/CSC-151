/**
 * This program will prompt the user to enter 
 * to enter the miles they have driven and 
 * the gallons they used on their trip. The
 * program will process the information and 
 * output the miles per gallon.
 * March 
 * CSC 151 Tutorial 2 - Miles-per-Gallon Problem
 * Miguel Ivan Orona
 */
package mpg_oronamiguel;
import java.util.Scanner;
/**
 *
 * @author oronam7447
 */
public class Mpg_OronaMiguel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
    double miles_MIO; //Miles driven
    double gallons_MIO; //gallons used
    double mpg_MIO; //miles-per-gallon
    
    Scanner keyboard = new Scanner(System.in);
    
    //Prompt the user to enter miles driven.
    System.out.print("Enter the miles driven: ");
    miles_MIO = keyboard.nextDouble();
    
    //prompt the user to enter the gallons used.
    System.out.print("Enter the gallons used: ");
    gallons_MIO = keyboard.nextDouble();
    
    //Calculate miles-per-gallons.
    mpg_MIO = miles_MIO / gallons_MIO;
    
    //Display the miles-per-gallon.
    System.out.println("The MPG is " + mpg_MIO);
    //End program.
    }
    
}
